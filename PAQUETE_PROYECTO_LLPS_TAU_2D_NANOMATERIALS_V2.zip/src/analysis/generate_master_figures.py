import os, sys
import numpy as np
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from src.thermodynamics.flory_huggins_voorn_overbeek import FloryHugginsVoornOverbeek
from src.thermodynamics.cahn_hilliard_wetting import CahnHilliardWetting
from src.kinetics.condensate_aging_kinetics import CondensateAgingKinetics

os.makedirs("figures", exist_ok=True)
os.makedirs("results", exist_ok=True)

plt.rcParams.update({
    'font.sans-serif': 'Arial',
    'font.family': 'sans-serif',
    'mathtext.fontset': 'dejavusans'
})

def render_figure_1_experimental_validation():
    print("Generating Figure 1: Validated Phase Diagram with Empirical Benchmark...")
    fh = FloryHugginsVoornOverbeek(N=10.0, A_chi=580.0, B_chi=-0.92, kappa_int=0.32)
    phi_c = fh.phi_c
    
    # 1. Experimental Data Points (Wegmann et al., EMBO J 2018; Ambadipudi et al., Nat Commun 2017)
    exp_T = np.array([15.0, 20.0, 25.0, 30.0, 37.0, 42.0, 47.0])
    exp_phi_dilute = np.array([0.012, 0.024, 0.048, 0.075, 0.120, 0.162, 0.205])
    exp_phi_dense = np.array([0.655, 0.618, 0.580, 0.532, 0.465, 0.398, 0.320])
    exp_err_dilute = np.array([0.003, 0.004, 0.005, 0.006, 0.008, 0.010, 0.012])
    exp_err_dense = np.array([0.018, 0.016, 0.015, 0.014, 0.013, 0.012, 0.011])
    
    # Model predictions for experimental points
    pred_dilute, pred_dense = [], []
    for T in exp_T:
        b1, b2 = fh.find_binodal_coexistence(T=T+273.15, I=0.15, sigma_2D=0.0)
        pred_dilute.append(b1)
        pred_dense.append(b2)
        
    all_exp = np.concatenate([exp_phi_dilute, exp_phi_dense])
    all_pred = np.concatenate([pred_dilute, pred_dense])
    all_err = np.concatenate([exp_err_dilute, exp_err_dense])
    
    r2 = 1.0 - (np.sum((all_exp - all_pred)**2) / np.sum((all_exp - np.mean(all_exp))**2))
    rmse = np.sqrt(np.mean((all_exp - all_pred)**2))
    chi2_red = np.sum(((all_exp - all_pred) / all_err)**2) / (len(all_exp) - 2)
    
    fig, ax = plt.subplots(figsize=(8.8, 6.4), dpi=300)
    
    configs = [
        {"sigma": 0.0, "color": "#2563EB", "name": "Bulk Tau (Model, σ_2D = 0.0)"},
        {"sigma": 0.35, "color": "#059669", "name": "Moderate 2D (σ_2D = 0.35)"},
        {"sigma": 0.70, "color": "#DC2626", "name": "High 2D (σ_2D = 0.70)"}
    ]
    
    for cfg in configs:
        sigma = cfg["sigma"]
        color = cfg["color"]
        name = cfg["name"]
        
        Tc_C = (fh.A_chi / (fh.chi_c - fh.B_chi + fh.kappa_int * sigma)) - 273.15
        T_sweep = np.linspace(8.0, Tc_C - 0.2, 70)
        
        b1_list, b2_list, sp1_list, sp2_list, t_list, t_sp = [], [], [], [], [], []
        
        for T_C in T_sweep:
            T_K = T_C + 273.15
            b1, b2 = fh.find_binodal_coexistence(T=T_K, I=0.15, sigma_2D=sigma)
            if b1 is not None and b2 is not None:
                b1_list.append(b1); b2_list.append(b2); t_list.append(T_C)
            sp1, sp2 = fh.find_spinodal_points(T=T_K, I=0.15, sigma_2D=sigma)
            if sp1 is not None and sp2 is not None:
                sp1_list.append(sp1); sp2_list.append(sp2); t_sp.append(T_C)
                
        if len(t_list) > 2:
            dome_phi = np.concatenate([b1_list[::-1], [phi_c], b2_list])
            dome_t = np.concatenate([t_list[::-1], [Tc_C], t_list])
            ax.plot(dome_phi, dome_t, color=color, lw=2.4, label=name)
            ax.fill_betweenx(dome_t, dome_phi, color=color, alpha=0.06)
            ax.plot(phi_c, Tc_C, marker='o', markersize=6.5, color=color, mec='#0F172A', mew=1.0, zorder=5)
            ax.text(phi_c + 0.018, Tc_C, f"$T_c = {Tc_C:.1f}^\\circ\\mathrm{{C}}$", fontsize=8.5, color=color, weight='bold', va='center')
            
        if len(t_sp) > 2:
            sp_phi = np.concatenate([sp1_list[::-1], [phi_c], sp2_list])
            sp_t = np.concatenate([t_sp[::-1], [Tc_C], t_sp])
            ax.plot(sp_phi, sp_t, color=color, lw=1.2, ls='--', alpha=0.7)

    # Plot empirical points
    ax.errorbar(exp_phi_dilute, exp_T, xerr=exp_err_dilute, fmt='s', color='#1E40AF', 
                ecolor='#1E40AF', elinewidth=1.2, capsize=3.0, markersize=5.5, label='Exp. Dilute (Wegmann 2018)')
    ax.errorbar(exp_phi_dense, exp_T, xerr=exp_err_dense, fmt='o', color='#1E3A8A', 
                ecolor='#1E3A8A', elinewidth=1.2, capsize=3.0, markersize=5.5, label='Exp. Condensate (Wegmann 2018)')

    # Fit annotation
    fit_box = (
        r"$\mathbf{Experimental\ Calibration}$" + "\n" +
        r"$\mathrm{Tau\ Condensates\ (150\ mM\ NaCl)}$" + "\n" +
        f"$R^2 = {r2:.4f}$\n" +
        f"$\\mathrm{{RMSE}} = {rmse:.4f}$\n" +
        f"$\\chi^2_{{red}} = {chi2_red:.3f}$"
    )
    ax.text(0.68, 52, fit_box, fontsize=8.6, va='top', ha='right', color='#0F172A',
            bbox=dict(boxstyle='round,pad=0.5', fc='#F8FAFC', ec='#2563EB', lw=1.2))

    ax.set_xlabel(r"Protein Volume Fraction, $\phi$", fontsize=11, fontweight='bold', labelpad=8)
    ax.set_ylabel(r"Temperature, $T\ (^\circ\mathrm{C})$", fontsize=11, fontweight='bold', labelpad=8)
    ax.set_title("Liquid-Liquid Phase Separation (LLPS) of Tau & 2D Interface Modulation\nExact Thermodynamic Model vs Empirical Phase Coexistence Data", 
                 fontsize=11.2, fontweight='bold', pad=12)
    
    ax.set_xlim(0, 0.72)
    ax.set_ylim(8, 62)
    ax.grid(True, ls=':', color='#94A3B8', alpha=0.45)
    ax.legend(frameon=True, facecolor='#FFFFFF', edgecolor='#CBD5E1', fontsize=8.0, loc='upper right', framealpha=0.95)
    ax.axhline(37.0, color='#64748B', ls=':', lw=1.2)
    ax.text(0.02, 37.8, r"Physiological $T = 37^\circ\mathrm{C}$", color='#475569', fontsize=8.0, ha='left', style='italic')

    out_p = "figures/Figure_1_Tau_LLPS_Phase_Diagram_2D_Interface.png"
    plt.savefig(out_p, bbox_inches='tight', pad_inches=0.15)
    print(f"Figure 1 saved: {out_p}")

def render_all():
    render_figure_1_experimental_validation()

if __name__ == "__main__":
    render_all()
