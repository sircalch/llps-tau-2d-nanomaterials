"""
flory_huggins_voorn_overbeek.py  (v2 — Revision Major)
=======================================================
Thermodynamic model for Tau LLPS modulated by 2D nanomaterial interfaces.

KEY CHANGE from v1:
  - The effective chi parameter chi(T) depends ONLY on temperature, NOT on sigma_2D.
  - The modulation of LLPS by 2D interfaces enters via adsorption equilibrium:
      Tau_bulk ⇌ Tau_ads    K_ads = exp(-ΔG_ads / RT)
  - This means LLPS suppression is an EMERGENT consequence of monomer sequestration,
    not an algebraic assumption built into chi.
  - See material_parameters.py for physical values of ΔG_ads, Gamma_max per material.

System of reference:
  Tau K18 (residues 244-372), 150 mM NaCl, 20 mM HEPES pH 7.4, 37°C.
  Calibrated against: Wegmann et al. EMBO J 2018, 37:e98049.

Authors: Monreal-Hernández et al. (2026)
"""

import numpy as np
from scipy.optimize import minimize_scalar, root_scalar

try:
    from .material_parameters import adsorption_equilibrium, TAU_SYSTEM
except ImportError:
    from material_parameters import adsorption_equilibrium, TAU_SYSTEM


class FloryHugginsVoornOverbeek:
    """
    Flory-Huggins-Voorn-Overbeek free energy for Tau K18 LLPS.

    Free energy density (dimensionless, units of k_B T per lattice site):

        f(φ) = (φ/N) ln φ + (1−φ) ln(1−φ)      [conformational entropy]
               + χ(T) φ(1−φ)                     [enthalpic interaction]
               − α_DH I^(3/2) φ/(φ + φ_0)        [electrostatic screening]

    The 2D material interface enters via the effective free concentration φ_free(T)
    computed from adsorption equilibrium in material_parameters.py.

    Parameters
    ----------
    N : float
        Effective chain length (Flory segment number). For Tau K18: N ≈ 10
        encoding the repeat-unit nature of the VQIVYK/VQIINK amyloidogenic segments.
    A_chi : float
        Enthalpic coefficient (K). chi(T) = A_chi / T + B_chi.
        Calibrated to match Tc(exp) = 51.5°C for Tau K18 at 150 mM NaCl.
    B_chi : float
        Entropic offset of chi(T).
    alpha_DH : float
        Debye-Hückel electrostatic coefficient (Voorn-Overbeek term).
    phi_0 : float
        Electrostatic regularization concentration.
    """

    def __init__(self, N=10.0, A_chi=580.0, B_chi=-0.92,
                 alpha_DH=0.08, phi_0=0.02):
        self.N = float(N)
        self.A_chi = float(A_chi)
        self.B_chi = float(B_chi)
        self.alpha_DH = float(alpha_DH)
        self.phi_0 = float(phi_0)

        # Critical point coordinates (analytical, no interface)
        self.phi_c = 1.0 / (1.0 + np.sqrt(self.N))
        self.chi_c = (1.0 + np.sqrt(self.N)) ** 2 / (2.0 * self.N)

    # ------------------------------------------------------------------
    # Core thermodynamic functions (no interface — pure bulk model)
    # ------------------------------------------------------------------

    def chi(self, T):
        """
        Effective Flory-Huggins interaction parameter.
        Depends ONLY on temperature — NOT on sigma_2D.
        Interface modulation enters via phi_free (see adsorption_equilibrium).
        """
        return (self.A_chi / T) + self.B_chi

    def free_energy_density(self, phi, T=298.15, I=0.15):
        """Dimensionless free energy density f(φ) at temperature T and ionic strength I."""
        phi = np.clip(phi, 1e-12, 1.0 - 1e-12)
        f_mix = (phi / self.N) * np.log(phi) + (1.0 - phi) * np.log(1.0 - phi)
        f_int = self.chi(T) * phi * (1.0 - phi)
        f_elec = -self.alpha_DH * (I ** 1.5) * (phi / (phi + self.phi_0))
        return f_mix + f_int + f_elec

    def chemical_potential(self, phi, T=298.15, I=0.15):
        """Exchange chemical potential μ(φ) = df/dφ."""
        phi = np.clip(phi, 1e-12, 1.0 - 1e-12)
        d_mix = (1.0 / self.N) * (np.log(phi) + 1.0) - np.log(1.0 - phi) - 1.0
        d_int = self.chi(T) * (1.0 - 2.0 * phi)
        d_elec = -self.alpha_DH * (I ** 1.5) * (self.phi_0 / (phi + self.phi_0) ** 2)
        return d_mix + d_int + d_elec

    def osmotic_pressure(self, phi, T=298.15, I=0.15):
        """Dimensionless osmotic pressure Π(φ) = φ·μ(φ) − f(φ)."""
        return phi * self.chemical_potential(phi, T, I) - self.free_energy_density(phi, T, I)

    def spinodal_derivative(self, phi, T=298.15, I=0.15):
        """Second derivative d²f/dφ² (spinodal condition: d²f/dφ² = 0)."""
        phi = np.clip(phi, 1e-12, 1.0 - 1e-12)
        d2_mix = 1.0 / (self.N * phi) + 1.0 / (1.0 - phi)
        d2_int = -2.0 * self.chi(T)
        d2_elec = 2.0 * self.alpha_DH * (I ** 1.5) * self.phi_0 / (phi + self.phi_0) ** 3
        return d2_mix + d2_int + d2_elec

    # ------------------------------------------------------------------
    # Coexistence solvers (Grand Canonical Potential, exact)
    # ------------------------------------------------------------------

    def find_binodal_coexistence(self, T=298.15, I=0.15, phi_total=None,
                                  sigma_2D=0.0, material="borophene"):
        """
        Compute the two-phase coexistence concentrations (φ_dilute, φ_dense)
        via exact Grand Canonical Potential minimization.

        Physics: for a given chemical potential μ*, the stable phases are the
        two minima of the grand potential Ω(φ, μ*) = f(φ) − μ*·φ.
        μ* is chosen such that Ω(φ_dilute, μ*) = Ω(φ_dense, μ*).

        If material is specified (not 'generic_2d') and sigma_2D > 0,
        the effective protein concentration available for LLPS is reduced
        to phi_free via adsorption equilibrium — this is how 2D interfaces
        suppress LLPS in a physically transparent way.

        Returns
        -------
        phi_dilute, phi_dense : float or None
            Coexisting volume fractions. Returns (None, None) if T > Tc.
        """
        # Effective free concentration after adsorption
        if sigma_2D > 0.0 and phi_total is not None:
            phi_eff, _, _ = adsorption_equilibrium(phi_total, T, sigma_2D, material)
        else:
            phi_eff = None  # solve coexistence in the standard (T-only) way

        c = self.chi(T)
        if c <= self.chi_c:
            return None, None

        def grand_potential(phi, mu_val):
            return self.free_energy_density(phi, T, I) - mu_val * phi

        def diff_omega(mu_val):
            r1 = minimize_scalar(lambda p: grand_potential(p, mu_val),
                                 bounds=(1e-7, self.phi_c), method='bounded')
            r2 = minimize_scalar(lambda p: grand_potential(p, mu_val),
                                 bounds=(self.phi_c, 0.9999), method='bounded')
            return r1.fun - r2.fun

        try:
            sol = root_scalar(diff_omega, bracket=[-4.0, 1.5], method='brentq')
            mu_star = sol.root
            p1 = minimize_scalar(lambda p: grand_potential(p, mu_star),
                                 bounds=(1e-7, self.phi_c), method='bounded').x
            p2 = minimize_scalar(lambda p: grand_potential(p, mu_star),
                                 bounds=(self.phi_c, 0.9999), method='bounded').x
            if 0 < p1 < self.phi_c < p2 < 1:
                return float(p1), float(p2)
        except Exception:
            pass
        return None, None

    def find_spinodal_points(self, T=298.15, I=0.15):
        """Compute spinodal boundaries (φ_sp1, φ_sp2) from d²f/dφ² = 0."""
        c = self.chi(T)
        if c <= self.chi_c:
            return None, None
        try:
            s1 = root_scalar(lambda p: self.spinodal_derivative(p, T, I),
                             bracket=[1e-7, self.phi_c], method='brentq')
            s2 = root_scalar(lambda p: self.spinodal_derivative(p, T, I),
                             bracket=[self.phi_c, 0.9999], method='brentq')
            if s1.converged and s2.converged:
                return float(s1.root), float(s2.root)
        except Exception:
            pass
        return None, None

    def effective_Tc_material(self, sigma_2D, phi_total=0.10, material="borophene",
                               T_range=(280.0, 380.0), n_T=100):
        """
        Compute the effective critical temperature for a given material and sigma_2D
        by finding the highest T at which two-phase coexistence still exists
        after accounting for adsorption equilibrium.

        This is the proper material-dependent Tc — it is NOT imposed algebraically,
        but emerges from the interplay of phi_free(T, sigma_2D, material) and chi(T).
        """
        T_vals = np.linspace(T_range[0], T_range[1], n_T)
        last_T_coex = T_range[0]
        for T in T_vals:
            phi_free, _, _ = adsorption_equilibrium(phi_total, T, sigma_2D, material)
            # Check if phi_free is inside the two-phase region
            b1, b2 = self.find_binodal_coexistence(T=T, I=0.15)
            if b1 is not None and b2 is not None and b1 < phi_free < b2:
                last_T_coex = T
        return last_T_coex - 273.15  # return in Celsius
