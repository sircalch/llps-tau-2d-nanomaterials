"""
cahn_hilliard_wetting.py  (v2 — Revision Major)
================================================
Cahn-Hilliard interfacial gradient theory for condensate wetting on 2D surfaces.

KEY CHANGE from v1:
  - The contact angle expression is now DERIVED from Young's equation, not assumed.
  - Units of h_s, kappa_grad, gamma_LL, v0 are explicitly documented and consistent.
  - See derivation in docstring of `young_contact_angle()`.

Derivation of Contact Angle from Young's Equation
--------------------------------------------------
Young's equation relates the three surface tensions at the three-phase contact line:

    γ_{S,dilute} − γ_{S,dense} = γ_{LL} · cos θ_c            ... (Young)

For the Cahn-Hilliard functional with a LINEAR surface anchoring term:

    f_surface(φ) = −h_s · φ

the solid-fluid surface excess free energy for each phase is:

    γ_{S,α} = ∫_0^∞ [f(φ(z)) − f(φ_α) − μ_coex(φ(z) − φ_α)] dz  [bulk term]
              − h_s · φ_α                                           [surface term]

where φ_α is the bulk value at coexistence.

Taking the difference:
    γ_{S,dilute} − γ_{S,dense} = −h_s · φ_dilute + h_s · φ_dense
                                = h_s · (φ_dense − φ_dilute)

Therefore:
    cos θ_c = h_s · (φ_dense − φ_dilute) / γ_{LL}               ... (DERIVED)

This is valid when:
  1. The surface anchoring is linear in φ (one-parameter Cahn model).
  2. The interface profile φ(z) is determined by the bulk free energy (planar approximation).
  3. |cos θ_c| ≤ 1; otherwise complete wetting (θ_c → 0) or dewetting (θ_c → π).

Reference: Sullivan & Telo da Gama, Fluid Interfacial Phenomena, 1986, Ch. 2.
           Bonn et al. Rev. Mod. Phys. 81, 739 (2009), Sec. III.B.

Units (INTERNALLY CONSISTENT):
  - φ            : dimensionless (volume fraction)
  - f(φ)         : dimensionless (k_B T per lattice site)
  - κ_grad       : k_B T · v_0^(5/3)   → SI: J·m² / m³ = J/m  ... gradient energy
  - γ_{LL}       : k_B T / v_0^(2/3)   → SI: J/m² = N/m
  - h_s          : J/m²                 → from material_parameters.py
  - v_0          : m³                   (monomer reference volume)

Authors: Monreal-Hernández et al. (2026)
"""

import numpy as np
from scipy.integrate import quad

try:
    from .material_parameters import h_s_SI, MATERIAL_PARAMS
    from .flory_huggins_voorn_overbeek import FloryHugginsVoornOverbeek
except ImportError:
    from material_parameters import h_s_SI, MATERIAL_PARAMS
    from flory_huggins_voorn_overbeek import FloryHugginsVoornOverbeek

# Physical constants
KB_J = 1.381e-23   # J/K
N_AVO = 6.022e23   # mol⁻¹

# Reference monomer volume for Tau K18:
#   MW_K18 ≈ 14,000 Da; density_protein ≈ 1.35 g/cm³
#   v0 = MW / (rho * N_Avo) = 14000 / (1350 * 6.022e23) ≈ 1.72e-26 m³ = 17.2 nm³
V0_M3 = 1.72e-26   # m³ (Tau K18 monomer reference volume)


class CahnHilliardWetting:
    """
    Compute condensate-surface wetting properties from Cahn-Hilliard theory.

    The liquid-liquid surface tension γ_LL is computed from the grand canonical
    excess free energy integrated across the diffuse interface profile.

    The contact angle on a 2D material surface is derived from Young's equation
    combined with a linear surface anchoring term (Cahn 1977).

    Parameters
    ----------
    fh_model : FloryHugginsVoornOverbeek
        Configured FH-VO thermodynamic model instance.
    kappa_grad : float
        Gradient energy coefficient in units of k_B T · v_0^(5/3).
        Estimated from: κ_grad ≈ (1/6) · a² · chi_c
        where a is the effective segment length (~0.5 nm for Tau).
        Default: 0.5 (dimensionless ratio; converted in SI calculations).
    T_ref : float
        Reference temperature for SI unit conversions (K).
    """

    def __init__(self, fh_model=None, kappa_grad=0.5, T_ref=310.15):
        if fh_model is None:
            fh_model = FloryHugginsVoornOverbeek()
        self.fh = fh_model
        self.kappa_grad = float(kappa_grad)
        self.T_ref = float(T_ref)

        # SI conversion factor: k_B T / v_0^(2/3) → J/m²
        self.gamma_scale_SI = (KB_J * T_ref) / (V0_M3 ** (2.0 / 3.0))

    # ------------------------------------------------------------------
    # Grand canonical excess potential (integrand for γ_LL)
    # ------------------------------------------------------------------

    def _grand_potential_excess(self, phi, T=310.15, I=0.15,
                                 phi_dilute=None, phi_dense=None):
        """
        Ω_excess(φ) = f(φ) − [μ_coex · φ − Π_coex]

        This is the "integrand" for the surface tension integral:
            γ_LL = ∫ sqrt(2 · κ_grad · Ω_excess(φ)) dφ

        Computed between the two coexisting phases.
        """
        if phi_dilute is None or phi_dense is None:
            phi_dilute, phi_dense = self.fh.find_binodal_coexistence(T=T, I=I)
            if phi_dilute is None:
                return 0.0

        mu_coex = self.fh.chemical_potential(phi_dilute, T, I)
        Pi_coex = self.fh.osmotic_pressure(phi_dilute, T, I)
        f_phi = self.fh.free_energy_density(phi, T, I)
        return max(0.0, f_phi - mu_coex * phi + Pi_coex)

    # ------------------------------------------------------------------
    # Liquid-Liquid Surface Tension γ_LL
    # ------------------------------------------------------------------

    def gamma_LL_dimensionless(self, T=310.15, I=0.15):
        """
        Compute the liquid-liquid surface tension in DIMENSIONLESS units
        (k_B T / v_0^(2/3)).

            γ_LL = ∫_{φ_dilute}^{φ_dense} sqrt(2 · κ · Ω_excess(φ)) dφ

        Reference: Rowlinson & Widom, Molecular Theory of Capillarity (1982).
        """
        phi_d, phi_c = self.fh.find_binodal_coexistence(T=T, I=I)
        if phi_d is None:
            return 0.0

        integrand = lambda phi: np.sqrt(max(0.0, 2.0 * self.kappa_grad *
                                            self._grand_potential_excess(phi, T, I, phi_d, phi_c)))
        result, _ = quad(integrand, phi_d + 1e-6, phi_c - 1e-6,
                         limit=80, epsabs=1e-10, epsrel=1e-8)
        return float(result)

    def gamma_LL_SI(self, T=310.15, I=0.15):
        """
        Liquid-liquid surface tension in SI units (J/m² = mN/m × 10⁻³).
        Typical experimental values for protein condensates: 0.01–10 µN/m.
        """
        gamma_dl = self.gamma_LL_dimensionless(T, I)
        return gamma_dl * self.gamma_scale_SI   # J/m²

    def gamma_LL_uNm(self, T=310.15, I=0.15):
        """Liquid-liquid surface tension in µN/m (convenient units for condensates)."""
        return self.gamma_LL_SI(T, I) * 1e6    # J/m² → µN/m

    # ------------------------------------------------------------------
    # Contact Angle: Derived from Young's Equation
    # ------------------------------------------------------------------

    def young_contact_angle(self, T=310.15, I=0.15, material="borophene"):
        """
        Compute the contact angle θ_c of a Tau condensate on a 2D material surface.

        DERIVATION (see module docstring for full derivation):

            Young:  γ_{S,dilute} − γ_{S,dense} = γ_{LL} · cos θ_c

            For linear surface anchoring f_s(φ) = −h_s · φ:

                γ_{S,dilute} − γ_{S,dense} = h_s · (φ_dense − φ_dilute)

            Therefore (derived, not assumed):

                cos θ_c = h_s · (φ_dense − φ_dilute) / γ_{LL}

        Unit check:
            h_s  [J/m²]
            (φ_dense − φ_dilute) [dimensionless]
            γ_LL [J/m²]
            → cos θ_c [dimensionless] ✓

        Returns
        -------
        theta_c_deg : float
            Contact angle in degrees. 0° = complete wetting (spreading film).
            180° = complete dewetting.
        wetting_regime : str
            'complete_wetting' (θ_c < 5°),
            'partial_wetting' (5° ≤ θ_c ≤ 120°),
            'dewetting' (θ_c > 120°).
        cos_theta : float
            Raw cosine value (clamped to [-1, 1]).
        gamma_LL : float
            Liquid-liquid surface tension used (J/m²).
        """
        phi_dilute, phi_dense = self.fh.find_binodal_coexistence(T=T, I=I)
        if phi_dilute is None:
            return 90.0, "no_phase_separation", 0.0, 0.0

        gamma_LL = self.gamma_LL_SI(T, I)
        if gamma_LL < 1e-20:
            return 90.0, "undefined", 0.0, gamma_LL

        # h_s in J/m² from material_parameters
        hs = h_s_SI(material)

        # Derived from Young + linear anchoring (see module docstring)
        cos_theta = hs * (phi_dense - phi_dilute) / gamma_LL
        cos_theta = np.clip(cos_theta, -1.0, 1.0)
        theta_deg = np.degrees(np.arccos(cos_theta))

        if theta_deg < 5.0:
            regime = "complete_wetting"
        elif theta_deg > 120.0:
            regime = "dewetting"
        else:
            regime = "partial_wetting"

        return float(theta_deg), regime, float(cos_theta), float(gamma_LL)

    # ------------------------------------------------------------------
    # Wetting Phase Map
    # ------------------------------------------------------------------

    def wetting_phase_map(self, T_range=(283.15, 323.15), n_T=40, I=0.15):
        """
        Compute wetting map across temperature for both materials.
        Returns dict with T array and per-material results.
        """
        T_vals = np.linspace(T_range[0], T_range[1], n_T)
        results = {}
        for mat in ["borophene", "mxene", "generic_2d"]:
            theta_list, cos_list, gamma_list = [], [], []
            for T in T_vals:
                theta, _, cos_t, gam = self.young_contact_angle(T=T, I=I, material=mat)
                theta_list.append(theta)
                cos_list.append(cos_t)
                gamma_list.append(gam * 1e6)  # µN/m
            results[mat] = {
                "theta_deg": np.array(theta_list),
                "cos_theta": np.array(cos_list),
                "gamma_LL_uNm": np.array(gamma_list),
            }
        results["T_C"] = T_vals - 273.15
        return results

    # ------------------------------------------------------------------
    # Unit Validation
    # ------------------------------------------------------------------

    def validate_units(self):
        """Print unit check table for all key quantities."""
        print("\n" + "=" * 60)
        print("UNIT VALIDATION TABLE — Cahn-Hilliard Wetting")
        print("=" * 60)
        print(f"v0        = {V0_M3:.3e} m³  (Tau K18 monomer volume)")
        print(f"k_B·T     = {1.381e-23 * self.T_ref:.3e} J  (at T={self.T_ref:.1f} K)")
        print(f"γ scale   = {self.gamma_scale_SI:.4e} J/m²  (k_B T / v0^(2/3))")
        gamma_dl = self.gamma_LL_dimensionless(T=self.T_ref)
        gamma_si = self.gamma_LL_SI(T=self.T_ref)
        print(f"γ_LL (dl) = {gamma_dl:.4f}  (dimensionless)")
        print(f"γ_LL (SI) = {gamma_si:.4e} J/m² = {gamma_si*1e6:.4f} µN/m")
        for mat in ["borophene", "mxene"]:
            hs = h_s_SI(mat)
            theta, regime, cos_t, _ = self.young_contact_angle(T=self.T_ref, material=mat)
            print(f"\n{mat:12s}:")
            print(f"  h_s = {hs:.4e} J/m²")
            print(f"  cos θ = {cos_t:.4f}  →  θ = {theta:.1f}°  [{regime}]")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    fh = FloryHugginsVoornOverbeek()
    wetting = CahnHilliardWetting(fh_model=fh)
    wetting.validate_units()
