import numpy as np
from scipy.integrate import solve_ivp

class CondensateAgingKinetics:
    """
    Kinetics of Liquid-to-Solid Phase Transition (Condensate Aging & Fibrillation)
    within Tau biomolecular condensates modulated by 2D Nanomaterial interfaces.
    
    Couples:
    1. Dense liquid phase monomer pool phi_dense(t).
    2. Primary and secondary fibril nucleation within droplet P_drop(t), M_drop(t).
    3. Monomer extraction and surface trapping by 2D nanosheets m_ads(t).
    """
    def __init__(self, k_n_drop=1.5e-4, k_2_drop=2.8e-2, k_plus=1.2e2, 
                 k_extract=0.85, k_desorb=0.02, n_c=2.0, n_2=2.0):
        self.k_n_drop = float(k_n_drop)     # Primary nucleation rate in dense droplet (h^-1)
        self.k_2_drop = float(k_2_drop)     # Secondary nucleation rate in dense droplet (h^-1)
        self.k_plus = float(k_plus)         # Fibril elongation rate (h^-1)
        self.k_extract = float(k_extract)   # Interfacial extraction rate by 2D nanosheet (h^-1)
        self.k_desorb = float(k_desorb)     # Desorption rate from 2D nanosheet (h^-1)
        self.n_c = float(n_c)               # Reaction order for primary nucleation
        self.n_2 = float(n_2)               # Reaction order for secondary nucleation

    def ode_system(self, t, y, sigma_2D):
        """
        State variables y:
        y[0] = phi_dense (liquid monomer volume fraction in droplet)
        y[1] = P_drop (fibril number density inside droplet)
        y[2] = M_drop (solid cross-beta fibril mass fraction inside droplet)
        y[3] = m_ads (peptide mass adsorbed on 2D nanosheets)
        """
        phi_dense = max(0.0, y[0])
        P_drop = max(0.0, y[1])
        M_drop = max(0.0, y[2])
        m_ads = max(0.0, y[3])
        
        # Surface capacity saturation on 2D interface
        theta = min(0.999, m_ads / (sigma_2D + 1e-8)) if sigma_2D > 0 else 1.0
        
        # 1. Nucleation fluxes within droplet
        J_prim = self.k_n_drop * (phi_dense ** self.n_c)
        J_sec = self.k_2_drop * (phi_dense ** self.n_2) * M_drop
        J_elong = 2.0 * self.k_plus * phi_dense * P_drop
        
        # 2. Interfacial extraction flux by 2D nanosheets
        J_extract = self.k_extract * sigma_2D * (1.0 - theta) * phi_dense - self.k_desorb * m_ads
        
        # Coupled differential equations
        dP_dt = J_prim + J_sec
        dM_dt = J_elong + self.n_c * J_prim + self.n_2 * J_sec
        dm_ads_dt = J_extract
        dphi_dense_dt = - dM_dt - J_extract
        
        return [dphi_dense_dt, dP_dt, dM_dt, dm_ads_dt]

    def simulate(self, t_span=(0, 72), n_eval=300, phi_0=0.60, sigma_2D=0.0):
        """Simulate droplet aging trajectory over time."""
        t_eval = np.linspace(t_span[0], t_span[1], n_eval)
        y0 = [phi_0, 1e-6, 0.0, 0.0]
        
        sol = solve_ivp(
            fun=lambda t, y: self.ode_system(t, y, sigma_2D),
            t_span=t_span,
            y0=y0,
            t_eval=t_eval,
            method='LSODA',
            rtol=1e-6,
            atol=1e-8
        )
        
        # Calculate lag time (time to reach 10% maximum fibril conversion)
        M_traj = sol.y[2]
        M_max = max(1e-6, np.max(M_traj))
        idx_lag = np.where(M_traj >= 0.10 * M_max)[0]
        t_lag = sol.t[idx_lag[0]] if len(idx_lag) > 0 and M_max > 0.05 else t_span[1]
        
        return {
            "time": sol.t,
            "phi_dense": sol.y[0],
            "P_drop": sol.y[1],
            "M_drop": sol.y[2],
            "m_ads": sol.y[3],
            "t_lag": float(t_lag),
            "M_final": float(M_traj[-1])
        }
